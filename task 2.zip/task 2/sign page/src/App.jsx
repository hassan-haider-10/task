import React, { useState } from 'react';
import './App.css'

const UserRegistrationForm = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    phoneNumber: '',
    address: '',
    dateOfBirth: '',
    gender: '',
    interests: [],
    agreeTerms: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData); // You can send this data to your backend for registration
    // Reset form after submission
    setFormData({
      fullName: '',
      email: '',
      password: '',
      phoneNumber: '',
      address: '',
      dateOfBirth: '',
      gender: '',
      interests: [],
      agreeTerms: false,
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>User Registration</h2>
      <label>
        Full Name:
        <input
          type="text"
          name="fullName"
          value={formData.fullName}
          onChange={handleChange}
          required
        />
      </label>
      <label>
        Email Address:
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />
      </label>
      <label>
        Password:
        <input
          type="password"
          name="password"
          value={formData.password}
          onChange={handleChange}
          required
        />
      </label>
      <label>
        Phone Number:
        <input
          type="tel"
          name="phoneNumber"
          value={formData.phoneNumber}
          onChange={handleChange}
        />
      </label>
      <label>
        Address:
        <input
          type="text"
          name="address"
          value={formData.address}
          onChange={handleChange}
        />
      </label>
      <label>
        Date of Birth:
        <input
          type="date"
          name="dateOfBirth"
          value={formData.dateOfBirth}
          onChange={handleChange}
        />
      </label>
      <label>
        Gender:
        <select name="gender" value={formData.gender} onChange={handleChange}>
          <option value="">Select</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
          <option value="other">Other</option>
        </select>
      </label>
      <fieldset>
        <legend>Interests:</legend>
        <label>
          <input
            type="checkbox"
            name="interests"
            value="technology"
            checked={formData.interests.includes('technology')}
            onChange={handleChange}
          />{' '}
          Technology
        </label>
        {/* Add more interest checkboxes as needed */}
      </fieldset>
      <label>
        <input
          type="checkbox"
          name="agreeTerms"
          checked={formData.agreeTerms}
          onChange={handleChange}
          required
        />{' '}
        I agree to the terms and conditions.
      </label>
      <button type="submit">Submit</button>
    </form>
  );
};

export default UserRegistrationForm;