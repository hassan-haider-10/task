import { useState } from 'react'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     <div className='login'>
      <div className='text'>ADMIN LOGIN</div>
      <br/> <br/>
      <div>
        <div className="col">
          <input className='username' type='text' placeholder='Username' />
        </div>
        <br/> 
        <div className="col">
        <input className='password' type='text' placeholder='Password' />
        </div>
      </div>
      <br/>
      <button className='btn'>Login</button>
     </div>
    </>
  )
}

export default App