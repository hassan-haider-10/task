
import React from 'react';
import './App.css';

function App() {
  return (
    <div>
      <Header />
      <Hero />
      <About />
      <Services />
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <header>
      <nav>
        <ul>
          <li><a href="#about">About</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
      <div className="contact-info">
        <p>Email: info@example.com</p>
        <p>Phone: +1 234 567 890</p>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section id="hero">
      <div className="hero-content">
        <h1>Welcome to Our Website</h1>
        <p>Your one-stop destination for amazing services.</p>
        <a href="#services" className="cta-button">Explore Services</a>
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about">
      <div className="container">
        <h2>About Us</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ut massa at dolor consequat finibus ut eget felis.</p>
      </div>
    </section>
  );
}

function Services() {
  return (
    <section id="services">
      <div className="container">
        <h2>Our Services</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam ut massa at dolor consequat finibus ut eget felis.</p>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer>
      <div className="container">
        <p>&copy; 2024 Interactive Landing Page. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default App;
